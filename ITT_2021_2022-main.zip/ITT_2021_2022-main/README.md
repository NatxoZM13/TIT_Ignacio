# ITT_2021_2022
Ingeniaritza Telematikoko Teknologia irakasgairako proba
